import ctypes
import glob
import hashlib
import hmac
import importlib.util
import json
import os
import re
import secrets
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import tkinter as tk
import urllib.parse
import urllib.request
import zipfile
from tkinter import filedialog, messagebox, simpledialog
from ctypes import wintypes
from pathlib import Path

from PIL import Image, ImageTk

try:
    import psutil
except ImportError:
    psutil = None

user32 = ctypes.windll.user32
kernel32 = ctypes.windll.kernel32
gdi32 = ctypes.windll.gdi32

LONG_PTR = ctypes.c_ssize_t
user32.SetParent.argtypes = [wintypes.HWND, wintypes.HWND]
user32.SetParent.restype = wintypes.HWND
user32.GetWindowLongPtrW.argtypes = [wintypes.HWND, ctypes.c_int]
user32.GetWindowLongPtrW.restype = LONG_PTR
user32.SetWindowLongPtrW.argtypes = [wintypes.HWND, ctypes.c_int, LONG_PTR]
user32.SetWindowLongPtrW.restype = LONG_PTR
user32.MoveWindow.argtypes = [wintypes.HWND, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, wintypes.BOOL]
user32.SetWindowPos.argtypes = [wintypes.HWND, wintypes.HWND, ctypes.c_int, ctypes.c_int, ctypes.c_int,
                                ctypes.c_int, wintypes.UINT]
user32.IsWindow.argtypes = [wintypes.HWND]
user32.ShowWindow.argtypes = [wintypes.HWND, ctypes.c_int]
kernel32.OpenProcess.restype = wintypes.HANDLE
user32.GetForegroundWindow.restype = wintypes.HWND
user32.GetAncestor.argtypes = [wintypes.HWND, wintypes.UINT]
user32.GetAncestor.restype = wintypes.HWND
user32.SetFocus.argtypes = [wintypes.HWND]
user32.WindowFromPoint.argtypes = [wintypes.POINT]
user32.WindowFromPoint.restype = wintypes.HWND
user32.IsChild.argtypes = [wintypes.HWND, wintypes.HWND]
user32.IsIconic.argtypes = [wintypes.HWND]
user32.SetForegroundWindow.argtypes = [wintypes.HWND]
user32.SetWindowRgn.argtypes = [wintypes.HWND, wintypes.HANDLE, wintypes.BOOL]
gdi32.CreateRectRgn.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int]
gdi32.CreateRectRgn.restype = wintypes.HANDLE

GWL_STYLE = -16
GWL_EXSTYLE = -20
WS_CHILD = 0x40000000
STRIP_STYLES = 0x00C00000 | 0x00040000 | 0x00080000 | 0x00020000 | 0x00010000 | 0x20000000 | 0x80000000
STRIP_EX = 0x00040000 | 0x00000001 | 0x00000100 | 0x00020000
SWP_NOZORDER = 0x0004
SWP_FRAMECHANGED = 0x0020
SWP_SHOWWINDOW = 0x0040
SWP_NOACTIVATE = 0x0010
GWL_OWNER = -8
WS_POPUP = 0x80000000
STRIP_OVERLAY = 0x00C00000 | 0x00040000 | 0x00080000 | 0x00020000 | 0x00010000 | 0x20000000
WS_EX_TOOLWINDOW = 0x00000080

HERE = Path(__file__).parent
VERSION = "1.0.0"
DEFAULT_UPDATE_SOURCE = "https://stribbits.github.io/stribbot-picks/hub/latest.json"
UPDATE_CHECK_SECONDS = 600
UPDATE_KEEP = {"hub.json", "users.json", "settings.json"}
ASSETS = HERE / "assets"
HOME = Path(os.environ.get("STRIBHUB_HOME") or HERE)
CONFIG = HERE / "hub.json"
LOGS = HERE / "logs"
USERS_FILE = HOME / "users.json"
PROFILES = HOME / "profiles"
NAME_RE = re.compile(r"^[A-Za-z0-9_.-]{2,24}$")

BG = "#0b1016"
PANEL = "#121820"
LINE = "#1f2833"
FG = "#e6edf3"
MUTED = "#7d8a99"
ACCENT = "#2fe0a5"
ACCENT_INK = "#04281d"
WARN = "#ffb454"
DANGER = "#ff6b6b"

DEFAULT_CONFIG = {
    "stribmeme": "",
    "stribmeme_exe": "",
    "taskforge_exe": "",
    "taskforge_url": "http://142.44.222.156:25617",
    "betting": {
        "site": "https://stribbits.github.io/stribbot-picks/",
        "window_title": "Stribbot",
        "card_url": "https://stribbits.github.io/stribbot-picks/data/card.json",
    },
    "tasks": [],
}


def load_config():
    if not CONFIG.exists():
        CONFIG.write_text(json.dumps(DEFAULT_CONFIG, indent=2))
        return dict(DEFAULT_CONFIG)
    try:
        data = json.loads(CONFIG.read_text())
    except ValueError:
        return dict(DEFAULT_CONFIG)
    data.setdefault("stribmeme", DEFAULT_CONFIG["stribmeme"])
    data.setdefault("stribmeme_exe", "")
    data.setdefault("update_source", "")
    data.setdefault("taskforge_exe", "")
    data.setdefault("taskforge_url", DEFAULT_CONFIG["taskforge_url"])
    data.setdefault("betting", {})
    for key, value in DEFAULT_CONFIG["betting"].items():
        data["betting"].setdefault(key, value)
    data.setdefault("tasks", [])
    changed = False
    if not data["stribmeme_exe"]:
        data["stribmeme_exe"] = resolve_shortcut(data["stribmeme"])
        changed = True
    if not data["taskforge_exe"]:
        guess = Path(r"C:\Claude\Task Forge\desktop\dist\TaskForge.exe")
        if guess.exists():
            data["taskforge_exe"] = str(guess)
            changed = True
    if changed:
        save_config(data)
    return data


def save_config(data):
    names = ("stribmeme", "stribmeme_exe", "taskforge_exe", "taskforge_url", "update_source", "betting", "tasks")
    keep = {k: data[k] for k in names if k in data}
    CONFIG.write_text(json.dumps(keep, indent=2))


def resolve_shortcut(path):
    if not path or not Path(path).exists() or not str(path).lower().endswith(".lnk"):
        return path if path and Path(path).exists() else ""
    try:
        result = subprocess.run(
            ["powershell", "-NoProfile", "-Command",
             f"(New-Object -ComObject WScript.Shell).CreateShortcut('{path}').TargetPath"],
            capture_output=True, text=True, timeout=20, creationflags=0x08000000)
        target = result.stdout.strip()
        return target if target and Path(target).exists() else ""
    except Exception:
        return ""


def hash_password(password, salt=None):
    salt = salt or secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 200000)
    return salt.hex(), digest.hex()


def load_users():
    if not USERS_FILE.exists():
        return {}
    try:
        return json.loads(USERS_FILE.read_text())
    except ValueError:
        return {}


def save_users(users):
    HOME.mkdir(parents=True, exist_ok=True)
    USERS_FILE.write_text(json.dumps(users, indent=2))


def add_user(users, name, password, role, legacy=False):
    key = name.strip().lower()
    if not NAME_RE.match(name.strip()):
        raise ValueError("Usernames are 2 to 24 letters, numbers, dots, dashes or underscores")
    if key in users:
        raise ValueError("That username already exists")
    if len(password) < 6:
        raise ValueError("Passwords need at least 6 characters")
    salt, digest = hash_password(password)
    users[key] = {"name": name.strip(), "salt": salt, "hash": digest, "role": role, "legacy": legacy,
                  "created": time.strftime("%Y-%m-%d %H:%M")}
    save_users(users)


def check_login(users, name, password):
    entry = users.get(name.strip().lower())
    if not entry:
        hash_password(password)
        return None
    _, digest = hash_password(password, bytes.fromhex(entry["salt"]))
    return entry if hmac.compare_digest(digest, entry["hash"]) else None


def profile_paths(user):
    if user.get("legacy"):
        (HERE / "chat-data").mkdir(exist_ok=True)
        return {"stribcro": None, "stribmeme": None, "taskforge": None, "browser": HERE / "browser-profile",
                "chat": HERE / "chat-data"}
    base = PROFILES / user["name"].lower()
    paths = {"stribcro": base / "stribcro", "stribmeme": base / "stribmeme", "browser": base / "browser-profile",
             "chat": base / "chat", "taskforge": base / "taskforge"}
    for path in paths.values():
        path.mkdir(parents=True, exist_ok=True)
    return paths


def cmdline_of(hwnd):
    if psutil is None:
        return None
    pid = wintypes.DWORD()
    user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
    try:
        return " ".join(psutil.Process(pid.value).cmdline())
    except Exception:
        return None


def parse_version(text):
    match = re.match(r"^v?(\d+)\.(\d+)\.(\d+)$", str(text).strip())
    return tuple(int(x) for x in match.groups()) if match else None


def update_source_of(config):
    return os.environ.get("STRIBHUB_UPDATE_SOURCE") or config.get("update_source") or DEFAULT_UPDATE_SOURCE


def read_source_bytes(source, name):
    if re.match(r"^https://", source, re.I):
        url = source if name is None else urllib.parse.urljoin(source, name)
        req = urllib.request.Request(f"{url}{'&' if '?' in url else '?'}t={int(time.time())}",
                                     headers={"User-Agent": "StribHub"})
        with urllib.request.urlopen(req, timeout=60) as resp:
            return resp.read()
    folder = Path(source)
    if folder.suffix.lower() == ".json":
        folder = folder.parent
    return (folder / (name or "latest.json")).read_bytes()


def check_for_update(config):
    source = update_source_of(config)
    manifest = json.loads(read_source_bytes(source, None).decode("utf-8"))
    latest, current = parse_version(manifest.get("version", "")), parse_version(VERSION)
    if not latest or not current or latest <= current:
        return None
    name = str(manifest.get("file", "")).strip()
    sha = str(manifest.get("sha256", "")).strip().lower()
    if not name or name != os.path.basename(name) or not name.lower().endswith(".zip"):
        raise ValueError("update manifest has an invalid file name")
    if not re.fullmatch(r"[0-9a-f]{64}", sha):
        raise ValueError("update manifest has an invalid sha256")
    return {"version": manifest["version"], "file": name, "sha256": sha, "notes": str(manifest.get("notes", "")),
            "source": source}


def download_update(info, folder):
    data = read_source_bytes(info["source"], info["file"])
    if hashlib.sha256(data).hexdigest() != info["sha256"]:
        raise ValueError("The downloaded update is damaged (its fingerprint doesn't match). Nothing was changed.")
    path = Path(folder) / info["file"]
    path.write_bytes(data)
    return path


def apply_update_zip(zip_path, dest):
    dest = Path(dest)
    with tempfile.TemporaryDirectory() as tmp:
        with zipfile.ZipFile(zip_path) as archive:
            for member in archive.namelist():
                target = (Path(tmp) / member).resolve()
                if not str(target).startswith(str(Path(tmp).resolve())):
                    raise ValueError("The update file has an unsafe path")
            archive.extractall(tmp)
        copied = []
        for item in Path(tmp).rglob("*"):
            if item.is_dir():
                continue
            relative = item.relative_to(tmp)
            if relative.parts[0] in UPDATE_KEEP and len(relative.parts) == 1:
                continue
            target = dest / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(item, target)
            copied.append(str(relative))
    return copied


def apply_icon(window):
    try:
        window.iconbitmap(default=str(ASSETS / "stribhub.ico"))
    except tk.TclError:
        pass


def wide_logo(height):
    img = Image.open(ASSETS / "stribbot_logo.png")
    width = max(1, int(img.width * height / img.height))
    return ImageTk.PhotoImage(img.resize((width, height), Image.LANCZOS))


def logo_image(height):
    img = Image.open(ASSETS / "stribbot_mark.png")
    width = max(1, int(img.width * height / img.height))
    return ImageTk.PhotoImage(img.resize((width, height), Image.LANCZOS))


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def exe_of(hwnd):
    pid = wintypes.DWORD()
    user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
    handle = kernel32.OpenProcess(0x1000, False, pid.value)
    if not handle:
        return ""
    try:
        buf = ctypes.create_unicode_buffer(1024)
        size = wintypes.DWORD(1024)
        if kernel32.QueryFullProcessImageNameW(handle, 0, buf, ctypes.byref(size)):
            return buf.value
        return ""
    finally:
        kernel32.CloseHandle(handle)


def find_app_window(exe_fragment, title_exact=None, accept=None):
    found = []

    @ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
    def visit(hwnd, _):
        if user32.IsWindowVisible(hwnd) and user32.GetParent(hwnd) == 0:
            n = user32.GetWindowTextLengthW(hwnd)
            if n:
                if title_exact is not None:
                    buf = ctypes.create_unicode_buffer(n + 1)
                    user32.GetWindowTextW(hwnd, buf, n + 1)
                    if buf.value != title_exact:
                        return True
                rect = wintypes.RECT()
                user32.GetWindowRect(hwnd, ctypes.byref(rect))
                if rect.right - rect.left > 300 and exe_fragment in os.path.basename(exe_of(hwnd)).lower():
                    if accept is None or accept(hwnd):
                        found.append(hwnd)
        return True

    user32.EnumWindows(visit, 0)
    return found[0] if found else None


class DockPage(tk.Frame):
    def __init__(self, master, title, launcher, exe_fragment, title_exact=None, accept=None, close_on_exit=False):
        super().__init__(master, bg=BG)
        self.accept = accept
        self.close_on_exit = close_on_exit
        self.title_text = title
        self.launcher = launcher
        self.exe_fragment = exe_fragment
        self.title_exact = title_exact
        self.hwnd = None
        self.saved = None
        self.launched_at = 0.0
        self.crop_top = 0
        self.shown = False
        self.last_key = None
        self.pending_reload = False
        self.host = tk.Frame(self, bg=BG)
        self.host.pack(fill="both", expand=True)
        self.message = tk.Label(self.host, text="", bg=BG, fg=MUTED, font=("Segoe UI", 12))
        self.message.place(relx=0.5, rely=0.45, anchor="center")
        self.reopen = tk.Button(self.host, text=f"Open {title}", bg=ACCENT, fg=ACCENT_INK, relief="flat",
                                font=("Segoe UI", 10, "bold"), activebackground=ACCENT, cursor="hand2",
                                command=self.start)
        self.host.bind("<Configure>", lambda e: self.sync())
        self.winfo_toplevel().bind("<Configure>", lambda e: self.sync(), add="+")
        self.winfo_toplevel().bind("<Unmap>", lambda e: self.sync(), add="+")
        self.winfo_toplevel().bind("<Map>", lambda e: self.sync(), add="+")
        self.after(800, self.watch)

    def find_window(self):
        return find_app_window(self.exe_fragment, self.title_exact, self.accept)

    def on_show(self):
        if not self.alive():
            self.start()
        else:
            self.sync(force=True)
            if self.pending_reload:
                self.pending_reload = False
                self.after(300, self.reload)

    def on_hide(self):
        self.hide_overlay()

    def on_docked(self):
        pass

    def hide_overlay(self):
        if self.alive() and self.shown:
            user32.ShowWindow(self.hwnd, 0)
        self.shown = False
        self.last_key = None

    def alive(self):
        return bool(self.hwnd) and bool(user32.IsWindow(self.hwnd))

    def start(self):
        self.reopen.place_forget()
        self.message.config(text=f"Starting {self.title_text}…")
        self.launched_at = time.time()
        if self.find_window() is None:
            try:
                self.launcher()
            except OSError as exc:
                self.message.config(text=f"Couldn't open {self.title_text}: {exc}")

    def watch(self):
        try:
            if self.alive():
                self.sync()
            elif self.hwnd:
                self.hwnd = None
                self.shown = False
                self.message.config(text=f"{self.title_text} was closed")
                self.reopen.place(relx=0.5, rely=0.52, anchor="center")
            elif self.launched_at and time.time() - self.launched_at < 60:
                hwnd = self.find_window()
                if hwnd:
                    self.dock(hwnd)
                    self.launched_at = 0.0
            elif self.winfo_ismapped() and not self.hwnd:
                hwnd = self.find_window()
                if hwnd:
                    self.dock(hwnd)
        finally:
            self.after(150 if (self.launched_at or self.hwnd) else 700, self.watch)

    def dock(self, hwnd):
        rect = wintypes.RECT()
        user32.GetWindowRect(hwnd, ctypes.byref(rect))
        self.saved = (
            user32.GetWindowLongPtrW(hwnd, GWL_STYLE),
            user32.GetWindowLongPtrW(hwnd, GWL_EXSTYLE),
            (rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top),
        )
        owner = user32.GetAncestor(self.host.winfo_id(), 2)
        style = (self.saved[0] & ~STRIP_OVERLAY) | WS_POPUP
        exstyle = (self.saved[1] & ~(0x00040000 | 0x00000001 | 0x00000100 | 0x00020000)) | WS_EX_TOOLWINDOW
        user32.SetWindowLongPtrW(hwnd, GWL_STYLE, style)
        user32.SetWindowLongPtrW(hwnd, GWL_EXSTYLE, exstyle)
        user32.SetWindowLongPtrW(hwnd, GWL_OWNER, owner)
        self.hwnd = hwnd
        self.message.config(text="")
        self.reopen.place_forget()
        self.shown = False
        self.last_key = None
        user32.SetWindowPos(hwnd, 0, 0, 0, 0, 0, 0x0001 | 0x0002 | SWP_NOZORDER | SWP_FRAMECHANGED | SWP_NOACTIVATE)
        self.sync(force=True)
        self.on_docked()

    def sync(self, force=False):
        if not self.alive():
            return
        root = user32.GetAncestor(self.host.winfo_id(), 2)
        wanted = self.winfo_ismapped() and not user32.IsIconic(root) and self.winfo_toplevel().state() != "iconic"
        if not wanted:
            self.hide_overlay()
            return
        rect = wintypes.RECT()
        user32.GetWindowRect(self.host.winfo_id(), ctypes.byref(rect))
        w, h = rect.right - rect.left, rect.bottom - rect.top
        if w < 50 or h < 50:
            return
        top = self.top_offset()
        key = (rect.left, rect.top, w, h, top)
        if not force and self.shown and key == self.last_key:
            return
        flags = SWP_NOZORDER | SWP_NOACTIVATE | SWP_SHOWWINDOW
        user32.SetWindowPos(self.hwnd, 0, rect.left, rect.top - top, w, h + top, flags)
        user32.SetWindowRgn(self.hwnd, gdi32.CreateRectRgn(0, top, w, h + top), True)
        self.shown = True
        self.last_key = key

    def fit(self):
        self.sync(force=True)

    def top_offset(self):
        if not self.crop_top:
            return 0
        dpi = user32.GetDpiForWindow(self.host.winfo_id()) or 96
        return int(self.crop_top * dpi / 96)

    def send_f5(self):
        if not self.alive() or not self.shown:
            return False
        user32.SetForegroundWindow(self.hwnd)
        time.sleep(0.05)
        user32.keybd_event(0x74, 0, 0, 0)
        user32.keybd_event(0x74, 0, 2, 0)
        return True

    def undock(self):
        if self.close_on_exit:
            if self.alive():
                user32.PostMessageW(self.hwnd, 0x0010, 0, 0)
            self.hwnd = None
            return
        if not self.alive() or not self.saved:
            return
        style, exstyle, (x, y, w, h) = self.saved
        user32.SetWindowRgn(self.hwnd, None, True)
        user32.SetWindowLongPtrW(self.hwnd, GWL_OWNER, 0)
        user32.SetWindowLongPtrW(self.hwnd, GWL_STYLE, style)
        user32.SetWindowLongPtrW(self.hwnd, GWL_EXSTYLE, exstyle)
        if w < 300 or h < 200 or x < -5000:
            x, y, w, h = 100, 100, 1200, 800
        user32.SetWindowPos(self.hwnd, 0, x, y, w, h, SWP_NOZORDER | SWP_FRAMECHANGED | SWP_SHOWWINDOW)
        self.hwnd = None


class PanelPage(tk.Frame):
    def __init__(self, master, title, subtitle, panel_class):
        super().__init__(master, bg=BG)
        card = tk.Frame(self, bg=PANEL, highlightbackground=LINE, highlightthickness=1)
        card.place(relx=0.5, rely=0.42, anchor="center")
        tk.Label(card, text=title, bg=PANEL, fg=FG, font=("Segoe UI", 13, "bold")).pack(anchor="w", padx=16, pady=(14, 0))
        tk.Label(card, text=subtitle, bg=PANEL, fg=MUTED, font=("Segoe UI", 9)).pack(anchor="w", padx=16, pady=(0, 6))
        self.panel = panel_class(card)
        self.panel.pack(padx=10, pady=(0, 12))

    def on_show(self):
        pass

    def undock(self):
        self.panel.shutdown()


def find_browser():
    pf, pfx, local = os.environ.get("ProgramFiles"), os.environ.get("ProgramFiles(x86)"), os.environ.get("LOCALAPPDATA")
    candidates = []
    for base in (pf, pfx, local):
        if base:
            candidates.append((Path(base) / "BraveSoftware" / "Brave-Browser" / "Application" / "brave.exe", "brave"))
            candidates.append((Path(base) / "Google" / "Chrome" / "Application" / "chrome.exe", "chrome"))
    for base in (pfx, pf):
        if base:
            candidates.append((Path(base) / "Microsoft" / "Edge" / "Application" / "msedge.exe", "msedge"))
    for path, fragment in candidates:
        if path.exists():
            return str(path), fragment
    return None, "msedge"


class WebDock(DockPage):
    def __init__(self, master, title, url, profile_dir, title_exact=None):
        self.url = url
        self.profile_dir = Path(profile_dir)
        self.proc = None
        self.browser, fragment = find_browser()
        super().__init__(master, title, self.launch_site, fragment, title_exact, self.accept_window)
        self.crop_top = 32

    def launch_site(self):
        if not self.browser:
            raise OSError("no browser was found")
        self.proc = subprocess.Popen([
            self.browser, f"--app={self.url}", f"--user-data-dir={self.profile_dir}", "--no-first-run",
            "--no-default-browser-check", "--disable-sync", "--window-size=1200,900",
            "--window-position=-32000,-32000",
        ])

    def accept_window(self, hwnd):
        cmd = cmdline_of(hwnd)
        return cmd is None or str(self.profile_dir) in cmd

    def kill_browser(self):
        if self.proc is not None:
            subprocess.run(["taskkill", "/F", "/T", "/PID", str(self.proc.pid)], capture_output=True,
                           creationflags=0x08000000)
            self.proc = None

    def reload(self):
        if self.alive():
            if not self.winfo_ismapped():
                self.pending_reload = True
                return
            if self.send_f5():
                return
        self.kill_browser()
        self.hwnd = None
        self.after(600, self.start)

    def undock(self):
        self.kill_browser()


class ApiError(Exception):
    def __init__(self, status, message):
        super().__init__(message)
        self.status = status


def server_call(config, method, path, body=None, token=None, timeout=180):
    url = config["taskforge_url"].rstrip("/") + "/api" + path
    headers = {"Content-Type": "application/json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    data = json.dumps(body).encode("utf-8") if body is not None else None
    try:
        req = urllib.request.Request(url, data=data, method=method, headers=headers)
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        detail = ""
        try:
            detail = json.loads(exc.read().decode("utf-8")).get("error", "")
        except Exception:
            pass
        raise ApiError(exc.code, detail or f"server error {exc.code}")
    except urllib.error.URLError as exc:
        raise ApiError(0, f"couldn't reach the server ({exc.reason})")


class AssistantChat(tk.Frame):
    def __init__(self, master, config, session_dir):
        super().__init__(master, bg=BG)
        self.config_data = config
        self.session_dir = Path(session_dir)
        self.session_dir.mkdir(parents=True, exist_ok=True)
        self.key_file = self.session_dir / "chat_key.json"
        self.history_file = self.session_dir / "history.json"
        self.key = ""
        self.history = []
        self.busy = False
        self.key_frame = tk.Frame(self, bg=BG)
        self.chat_frame = tk.Frame(self, bg=BG)
        self.build_key_screen()
        self.build_chat()
        self.load_state()

    def build_key_screen(self):
        card = tk.Frame(self.key_frame, bg=PANEL, highlightbackground=LINE, highlightthickness=1)
        card.place(relx=0.5, rely=0.4, anchor="center")
        tk.Label(card, text="Chat", bg=PANEL, fg=FG, font=("Segoe UI", 16, "bold")).pack(padx=48, pady=(24, 2))
        tk.Label(card, text="Paste your chat key to start", bg=PANEL, fg=MUTED, font=("Segoe UI", 10)).pack()
        tk.Label(card, text="Ask the studio admin for a chat key. You only do this once on this account.", bg=PANEL,
                 fg=MUTED, font=("Segoe UI", 9)).pack(pady=(2, 14))
        self.key_entry = tk.Entry(card, width=44, bg=BG, fg=FG, insertbackground=FG, relief="flat",
                                  font=("Segoe UI", 11), show="*")
        self.key_entry.pack(padx=48, pady=(2, 8), ipady=4)
        self.key_error = tk.Label(card, text="", bg=PANEL, fg=DANGER, font=("Segoe UI", 9), wraplength=360)
        self.key_error.pack(pady=(4, 0))
        tk.Button(card, text="Save key", width=16, bg=ACCENT, fg=ACCENT_INK, relief="flat", activebackground=ACCENT,
                  font=("Segoe UI", 11, "bold"), cursor="hand2", command=self.save_key).pack(pady=(10, 24))
        self.key_entry.bind("<Return>", lambda e: self.save_key())

    def build_chat(self):
        bar = tk.Frame(self.chat_frame, bg=PANEL, highlightbackground=LINE, highlightthickness=1)
        bar.pack(fill="x")
        tk.Label(bar, text="Chat", bg=PANEL, fg=MUTED, font=("Segoe UI", 10)).pack(side="left", padx=14, pady=8)
        for text, command in (("Change key", self.change_key), ("Clear chat", self.clear_chat)):
            tk.Button(bar, text=text, bg=PANEL, fg=FG, relief="flat", activebackground=LINE, activeforeground=FG,
                      font=("Segoe UI", 9), cursor="hand2", command=command).pack(side="right", padx=4)
        body = tk.Frame(self.chat_frame, bg=BG)
        body.pack(fill="both", expand=True, padx=24, pady=(12, 6))
        self.log = tk.Text(body, bg=BG, fg=FG, relief="flat", font=("Segoe UI", 11), wrap="word", state="disabled",
                           padx=8, pady=8, spacing3=6, highlightthickness=0)
        scroll = tk.Scrollbar(body, command=self.log.yview)
        self.log.configure(yscrollcommand=scroll.set)
        scroll.pack(side="right", fill="y")
        self.log.pack(side="left", fill="both", expand=True)
        self.log.tag_configure("name_user", foreground=ACCENT, font=("Segoe UI", 9, "bold"))
        self.log.tag_configure("name_bot", foreground=WARN, font=("Segoe UI", 9, "bold"))
        self.log.tag_configure("meta", foreground=MUTED, font=("Segoe UI", 9))
        self.log.tag_configure("error", foreground=DANGER)
        entry_row = tk.Frame(self.chat_frame, bg=BG)
        entry_row.pack(fill="x", padx=24, pady=(0, 16))
        self.entry = tk.Text(entry_row, height=3, bg=PANEL, fg=FG, insertbackground=FG, relief="flat",
                             font=("Segoe UI", 11), wrap="word", padx=8, pady=6)
        self.entry.pack(side="left", fill="x", expand=True)
        self.entry.bind("<Return>", self.on_enter)
        self.send_btn = tk.Button(entry_row, text="Send", width=10, bg=ACCENT, fg=ACCENT_INK, relief="flat",
                                  activebackground=ACCENT, font=("Segoe UI", 11, "bold"), cursor="hand2",
                                  command=self.send)
        self.send_btn.pack(side="left", padx=(8, 0), fill="y")

    def on_enter(self, event):
        if event.state & 0x0001:
            return None
        self.send()
        return "break"

    def load_state(self):
        try:
            self.key = json.loads(self.key_file.read_text()).get("key", "")
        except Exception:
            self.key = ""
        try:
            self.history = json.loads(self.history_file.read_text())
        except Exception:
            self.history = []
        self.show_state()
        self.redraw()

    def save_history(self):
        self.history_file.write_text(json.dumps(self.history[-200:]))

    def show_state(self):
        self.key_frame.pack_forget()
        self.chat_frame.pack_forget()
        if self.key:
            self.chat_frame.pack(fill="both", expand=True)
        else:
            self.key_frame.pack(fill="both", expand=True)

    def on_show(self):
        (self.entry if self.key else self.key_entry).focus_set()

    def undock(self):
        pass

    def save_key(self):
        key = self.key_entry.get().strip()
        if len(key) < 12:
            self.key_error.config(text="That doesn't look like a chat key")
            return
        self.key = key
        self.key_file.write_text(json.dumps({"key": key}))
        self.key_entry.delete(0, "end")
        self.key_error.config(text="")
        self.show_state()
        self.entry.focus_set()

    def change_key(self):
        self.key = ""
        try:
            self.key_file.unlink()
        except OSError:
            pass
        self.show_state()
        self.key_entry.focus_set()

    def bad_key(self):
        self.change_key()
        self.key_error.config(text="That chat key isn't valid any more. Ask the admin for a new one.")

    def write_clear(self):
        self.log.config(state="normal")
        self.log.delete("1.0", "end")
        self.log.config(state="disabled")

    def add_message(self, role, text, extra=None):
        self.log.config(state="normal")
        self.log.insert("end", "You\n" if role == "user" else "Claude\n", "name_user" if role == "user" else "name_bot")
        self.log.insert("end", text.strip() + "\n")
        if extra:
            self.log.insert("end", extra + "\n", "meta")
        self.log.insert("end", "\n")
        self.log.config(state="disabled")
        self.log.see("end")

    def note(self, text, tag="meta"):
        self.log.config(state="normal")
        self.log.insert("end", text + "\n\n", tag)
        self.log.config(state="disabled")
        self.log.see("end")

    def redraw(self):
        self.write_clear()
        for m in self.history:
            self.add_message(m.get("role", "assistant"), m.get("content", ""), m.get("extra"))

    def send(self):
        text = self.entry.get("1.0", "end").strip()
        if not text or self.busy:
            return
        self.busy = True
        self.entry.delete("1.0", "end")
        self.send_btn.config(state="disabled", text="Thinking…")
        self.history.append({"role": "user", "content": text})
        self.add_message("user", text)
        self.save_history()
        payload = [{"role": m["role"], "content": m["content"]} for m in self.history[-40:]]
        threading.Thread(target=self.send_job, args=(payload,), daemon=True).start()

    def send_job(self, payload):
        try:
            result = server_call(self.config_data, "POST", "/chat", {"messages": payload}, token=self.key)
            reply = result.get("reply", "")
            sources = result.get("sources") or []
            extra = ("Sources: " + ", ".join(str(x.get("title") or x.get("url")) for x in sources[:4])) if sources else None
            self.history.append({"role": "assistant", "content": reply, "extra": extra})
            self.save_history()
            self.after(0, lambda: self.add_message("assistant", reply, extra))
        except ApiError as exc:
            if self.history and self.history[-1]["role"] == "user":
                self.history.pop()
                self.save_history()
            if exc.status in (401, 403):
                self.after(0, self.bad_key)
            else:
                message = str(exc)
                self.after(0, lambda: self.note(f"That didn't go through: {message}", "error"))
        finally:
            self.busy = False
            self.after(0, lambda: self.send_btn.config(state="normal", text="Send"))

    def clear_chat(self):
        self.history = []
        self.save_history()
        self.write_clear()


class BetPage(WebDock):
    SITE_BG = "#0B1320"
    SITE_PANEL = "#121C2C"
    SITE_LINE = "#24344C"
    SITE_INK = "#E6EDF5"
    SITE_MUTED = "#8FA0B5"
    SITE_OK = "#4CC38A"

    def __init__(self, master, cfg, profile_dir):
        self.cfg = cfg
        self.card_stamp = None
        super().__init__(master, "StribBet", cfg["site"], profile_dir, cfg.get("window_title", "Stribbot"))
        self.configure(bg=self.SITE_BG)
        self.host.configure(bg=self.SITE_BG)
        self.message.configure(bg=self.SITE_BG)
        bar = tk.Frame(self, bg=self.SITE_PANEL, highlightbackground=self.SITE_LINE, highlightthickness=1)
        bar.pack(side="top", fill="x", before=self.host)
        self.status = tk.Label(bar, text="The page updates by itself when a new card is published", bg=self.SITE_PANEL,
                               fg=self.SITE_MUTED, font=("Segoe UI", 9), anchor="w", justify="left")
        self.status.pack(side="left", padx=12, pady=10, fill="x", expand=True)
        for text, command in (("Reload", self.reload), ("Open in browser", lambda: os.startfile(self.cfg["site"]))):
            tk.Button(bar, text=text, bg=self.SITE_PANEL, fg=self.SITE_INK, relief="flat",
                      activebackground=self.SITE_LINE, activeforeground=self.SITE_INK, font=("Segoe UI", 9),
                      cursor="hand2", command=command).pack(side="right", padx=4)
        self.after(8000, self.poll_card)

    def poll_card(self):
        threading.Thread(target=self.check_card, daemon=True).start()
        self.after(60000, self.poll_card)

    def check_card(self):
        try:
            req = urllib.request.Request(f"{self.cfg['card_url']}?t={int(time.time())}", headers={"User-Agent": "StribHub"})
            with urllib.request.urlopen(req, timeout=20) as resp:
                stamp = json.loads(resp.read().decode("utf-8")).get("updatedAt")
        except Exception:
            return
        if stamp is None:
            return
        if self.card_stamp is None:
            self.card_stamp = stamp
        elif stamp != self.card_stamp:
            self.card_stamp = stamp
            self.after(0, self.new_card)

    def new_card(self):
        self.set_status("A new card was published. Reloading the page…", self.SITE_OK)
        if self.winfo_ismapped() or self.alive():
            self.reload()
        self.after(8000, lambda: self.set_status("The page updates by itself when a new card is published"))

    def on_docked(self):
        self.set_status("The page updates by itself when a new card is published")

    def set_status(self, text, color=None):
        self.after(0, lambda: self.status.config(text=text, fg=color or self.SITE_MUTED))


class LoginWindow(tk.Tk):
    def __init__(self, users):
        super().__init__()
        self.users = users
        self.result = None
        self.setup = not users
        self.failures = 0
        self.title("StribHub")
        apply_icon(self)
        self.configure(bg=BG)
        self.resizable(False, False)
        self.tk.call("tk", "scaling", self.winfo_fpixels("1i") / 72 * 1.25)
        card = tk.Frame(self, bg=PANEL, highlightbackground=LINE, highlightthickness=1)
        card.pack(padx=30, pady=30)
        self.logo = wide_logo(70)
        tk.Label(card, image=self.logo, bg=PANEL).pack(padx=40, pady=(30, 12))
        sub = "Create the admin account for this PC" if self.setup else "Sign in"
        tk.Label(card, text=sub, bg=PANEL, fg=MUTED, font=("Segoe UI", 10)).pack(pady=(0, 14))
        self.name = self.field(card, "Username")
        self.password = self.field(card, "Password", True)
        self.confirm = self.field(card, "Confirm password", True) if self.setup else None
        self.error = tk.Label(card, text="", bg=PANEL, fg=DANGER, font=("Segoe UI", 9), wraplength=300)
        self.error.pack(pady=(6, 0))
        tk.Button(card, text="Create account" if self.setup else "Sign in", bg=ACCENT, fg=ACCENT_INK, relief="flat",
                  activebackground=ACCENT, font=("Segoe UI", 11, "bold"), cursor="hand2", width=16,
                  command=self.submit).pack(pady=(10, 24))
        self.bind("<Return>", lambda e: self.submit())
        self.update_idletasks()
        w, h = self.winfo_reqwidth(), self.winfo_reqheight()
        self.geometry(f"+{(self.winfo_screenwidth() - w) // 2}+{(self.winfo_screenheight() - h) // 3}")
        self.name.focus_set()

    def field(self, parent, label, secret=False):
        tk.Label(parent, text=label, bg=PANEL, fg=MUTED, font=("Segoe UI", 9), anchor="w").pack(fill="x", padx=40)
        entry = tk.Entry(parent, width=28, bg=BG, fg=FG, insertbackground=FG, relief="flat", font=("Segoe UI", 11),
                         show="*" if secret else "")
        entry.pack(padx=40, pady=(2, 8), ipady=4)
        return entry

    def submit(self):
        name, password = self.name.get().strip(), self.password.get()
        try:
            if self.setup:
                if password != self.confirm.get():
                    raise ValueError("The passwords don't match")
                add_user(self.users, name, password, "admin", legacy=True)
                self.result = self.users[name.lower()]
            else:
                if self.failures >= 5:
                    raise ValueError("Too many wrong tries. Close the app and open it again.")
                entry = check_login(self.users, name, password)
                if not entry:
                    self.failures += 1
                    raise ValueError("Wrong username or password")
                self.result = entry
        except ValueError as exc:
            self.error.config(text=str(exc))
            return
        self.destroy()


class AdminPage(tk.Frame):
    def __init__(self, master, hub):
        super().__init__(master, bg=BG)
        self.hub = hub
        tk.Label(self, text="Admin", bg=BG, fg=FG, font=("Segoe UI", 14, "bold")).pack(anchor="w", padx=24, pady=(20, 2))
        tk.Label(self, text="Create accounts for people who use StribHub on this PC. Each person gets their own StribMeme, "
                 "StribCro and StribBet data.", bg=BG, fg=MUTED, font=("Segoe UI", 10), wraplength=1000,
                 justify="left").pack(anchor="w", padx=24, pady=(0, 10))
        form = tk.Frame(self, bg=PANEL, highlightbackground=LINE, highlightthickness=1)
        form.pack(fill="x", padx=24, pady=4)
        tk.Label(form, text="New account", bg=PANEL, fg=FG, font=("Segoe UI", 11, "bold")).grid(
            row=0, column=0, columnspan=6, padx=12, pady=(10, 4), sticky="w")
        self.new_name = self.entry(form, "Username", 1, 0)
        self.new_pass = self.entry(form, "Password", 1, 2, True)
        self.role = tk.StringVar(value="user")
        tk.Label(form, text="Role", bg=PANEL, fg=MUTED, font=("Segoe UI", 9)).grid(row=1, column=4, padx=(12, 4))
        tk.OptionMenu(form, self.role, "user", "admin").grid(row=1, column=5, padx=(0, 12))
        tk.Button(form, text="Create account", bg=ACCENT, fg=ACCENT_INK, relief="flat", activebackground=ACCENT,
                  font=("Segoe UI", 10, "bold"), cursor="hand2", command=self.create).grid(
            row=2, column=0, columnspan=2, padx=12, pady=(6, 12), sticky="w")
        self.msg = tk.Label(form, text="", bg=PANEL, fg=MUTED, font=("Segoe UI", 9))
        self.msg.grid(row=2, column=2, columnspan=4, sticky="w")
        tk.Label(self, text="Accounts", bg=BG, fg=FG, font=("Segoe UI", 11, "bold")).pack(anchor="w", padx=24, pady=(14, 2))
        self.list_frame = tk.Frame(self, bg=BG)
        self.list_frame.pack(fill="x", padx=24)
        self.exe_vars = {}
        self.chat_key_card()
        self.program_row("StribMeme program on this PC", "stribmeme_exe")
        self.program_row("TaskForge program on this PC", "taskforge_exe")
        self.refresh()

    def chat_key_card(self):
        card = tk.Frame(self, bg=PANEL, highlightbackground=LINE, highlightthickness=1)
        card.pack(fill="x", padx=24, pady=(8, 6))
        tk.Label(card, text="Chat keys", bg=PANEL, fg=FG, font=("Segoe UI", 11, "bold")).pack(
            anchor="w", padx=12, pady=(10, 2))
        tk.Label(card, text="Make a key for each person. They paste it once into their Chat tab. You can cancel a key "
                 "later from the TaskForge admin page.", bg=PANEL, fg=MUTED, font=("Segoe UI", 9),
                 wraplength=1000, justify="left").pack(anchor="w", padx=12)
        row = tk.Frame(card, bg=PANEL)
        row.pack(fill="x", padx=12, pady=(8, 4))
        tk.Label(row, text="Who is it for?", bg=PANEL, fg=MUTED, font=("Segoe UI", 9)).pack(side="left")
        self.key_name = tk.Entry(row, width=22, bg=BG, fg=FG, insertbackground=FG, relief="flat", font=("Segoe UI", 10))
        self.key_name.pack(side="left", padx=8, ipady=3)
        tk.Button(row, text="Create chat key", bg=ACCENT, fg=ACCENT_INK, relief="flat", activebackground=ACCENT,
                  font=("Segoe UI", 10, "bold"), cursor="hand2", command=self.make_chat_key).pack(side="left")
        out = tk.Frame(card, bg=PANEL)
        out.pack(fill="x", padx=12, pady=(4, 12))
        self.key_out = tk.Entry(out, width=64, bg=BG, fg=ACCENT, relief="flat", font=("Consolas", 10),
                                readonlybackground=BG, state="readonly")
        self.key_out.pack(side="left", ipady=4)
        tk.Button(out, text="Copy", bg=PANEL, fg=FG, relief="flat", activebackground=LINE, cursor="hand2",
                  command=self.copy_chat_key).pack(side="left", padx=6)
        self.key_msg = tk.Label(out, text="", bg=PANEL, fg=MUTED, font=("Segoe UI", 9))
        self.key_msg.pack(side="left", padx=6)

    def make_chat_key(self):
        name = self.key_name.get().strip()
        if not name:
            self.key_msg.config(text="Type a name first", fg=DANGER)
            return
        email = simpledialog.askstring("TaskForge admin", "Your TaskForge admin email:", parent=self)
        if not email:
            return
        password = simpledialog.askstring("TaskForge admin", "Your TaskForge admin password:", show="*", parent=self)
        if not password:
            return
        self.key_msg.config(text="Creating…", fg=MUTED)
        threading.Thread(target=self.chat_key_job, args=(name, email.strip(), password), daemon=True).start()

    def chat_key_job(self, name, email, password):
        config = self.hub.config_data
        try:
            token = server_call(config, "POST", "/auth/login", {"email": email, "password": password}, timeout=30)["token"]
            created = server_call(config, "POST", "/admin/api-keys",
                                  {"name": f"Chat: {name}", "scopes": "chat"}, token=token, timeout=30)
            key = created["token"]
        except ApiError as exc:
            message = str(exc)
            self.after(0, lambda: self.key_msg.config(text=message, fg=DANGER))
            return

        def show():
            self.key_out.config(state="normal")
            self.key_out.delete(0, "end")
            self.key_out.insert(0, key)
            self.key_out.config(state="readonly")
            self.key_msg.config(text=f"Key for {name} is ready. Copy it now; it's only shown once.", fg=ACCENT)

        self.after(0, show)

    def copy_chat_key(self):
        value = self.key_out.get()
        if value:
            self.clipboard_clear()
            self.clipboard_append(value)
            self.key_msg.config(text="Copied", fg=ACCENT)

    def program_row(self, title, key):
        prog = tk.Frame(self, bg=PANEL, highlightbackground=LINE, highlightthickness=1)
        prog.pack(fill="x", padx=24, pady=(8, 6))
        tk.Label(prog, text=title, bg=PANEL, fg=FG, font=("Segoe UI", 11, "bold")).pack(
            anchor="w", padx=12, pady=(10, 2))
        row = tk.Frame(prog, bg=PANEL)
        row.pack(fill="x", padx=12, pady=(0, 12))
        var = tk.StringVar(value=self.hub.config_data.get(key, ""))
        self.exe_vars[key] = var
        tk.Entry(row, textvariable=var, width=70, bg=BG, fg=FG, insertbackground=FG, relief="flat",
                 font=("Segoe UI", 10)).pack(side="left", ipady=4)
        tk.Button(row, text="Browse…", bg=PANEL, fg=FG, relief="flat", activebackground=LINE, cursor="hand2",
                  command=lambda: self.browse(key)).pack(side="left", padx=6)
        tk.Button(row, text="Save", bg=PANEL, fg=FG, relief="flat", activebackground=LINE, cursor="hand2",
                  command=lambda: self.save_exe(key, title)).pack(side="left")

    def entry(self, parent, label, row, col, secret=False):
        tk.Label(parent, text=label, bg=PANEL, fg=MUTED, font=("Segoe UI", 9)).grid(row=row, column=col, padx=(12, 4))
        e = tk.Entry(parent, width=20, bg=BG, fg=FG, insertbackground=FG, relief="flat", font=("Segoe UI", 10),
                     show="*" if secret else "")
        e.grid(row=row, column=col + 1, padx=(0, 8), pady=4, ipady=3)
        return e

    def on_show(self):
        self.refresh()

    def undock(self):
        pass

    def say(self, text, color=None):
        self.msg.config(text=text, fg=color or MUTED)

    def create(self):
        try:
            add_user(self.hub.users, self.new_name.get(), self.new_pass.get(), self.role.get())
        except ValueError as exc:
            self.say(str(exc), DANGER)
            return
        self.say(f"Created {self.new_name.get().strip()}", ACCENT)
        self.new_name.delete(0, "end")
        self.new_pass.delete(0, "end")
        self.refresh()

    def refresh(self):
        for child in self.list_frame.winfo_children():
            child.destroy()
        admins = [u for u in self.hub.users.values() if u["role"] == "admin"]
        for key, u in sorted(self.hub.users.items()):
            row = tk.Frame(self.list_frame, bg=PANEL, highlightbackground=LINE, highlightthickness=1)
            row.pack(fill="x", pady=3)
            tk.Label(row, text=u["name"], bg=PANEL, fg=FG, font=("Segoe UI", 11, "bold")).pack(side="left", padx=12, pady=8)
            tk.Label(row, text=u["role"] + ("  ·  you" if key == self.hub.user["name"].lower() else ""), bg=PANEL,
                     fg=MUTED, font=("Segoe UI", 9)).pack(side="left")
            if key != self.hub.user["name"].lower() and not (u["role"] == "admin" and len(admins) <= 1):
                tk.Button(row, text="Delete", bg=PANEL, fg=DANGER, relief="flat", activebackground=LINE, cursor="hand2",
                          command=lambda k=key: self.delete(k)).pack(side="right", padx=8)
            tk.Button(row, text="Reset password", bg=PANEL, fg=FG, relief="flat", activebackground=LINE, cursor="hand2",
                      command=lambda k=key: self.reset(k)).pack(side="right", padx=4)

    def reset(self, key):
        password = simpledialog.askstring("Reset password", f"New password for {self.hub.users[key]['name']}:",
                                          show="*", parent=self)
        if not password:
            return
        if len(password) < 6:
            self.say("Passwords need at least 6 characters", DANGER)
            return
        salt, digest = hash_password(password)
        self.hub.users[key]["salt"], self.hub.users[key]["hash"] = salt, digest
        save_users(self.hub.users)
        self.say(f"Password changed for {self.hub.users[key]['name']}", ACCENT)

    def delete(self, key):
        name = self.hub.users[key]["name"]
        if not messagebox.askyesno("Delete account", f"Delete {name}'s account? Their saved data folder is kept on disk.",
                                      parent=self):
            return
        del self.hub.users[key]
        save_users(self.hub.users)
        self.say(f"Deleted {name}", ACCENT)
        self.refresh()

    def browse(self, key):
        path = filedialog.askopenfilename(filetypes=[("Programs", "*.exe")], parent=self)
        if path:
            self.exe_vars[key].set(path)

    def save_exe(self, key, title):
        self.hub.config_data[key] = self.exe_vars[key].get().strip()
        save_config(self.hub.config_data)
        self.say(f"{title.split(' program')[0]} program saved", ACCENT)


class Hub(tk.Tk):
    def __init__(self, user, users):
        super().__init__()
        self.user = user
        self.users = users
        self.restart = False
        self.relaunch = False
        self.pending_update = None
        self.popup = None
        self.paths = profile_paths(user)
        self.title("StribHub")
        apply_icon(self)
        self.configure(bg=BG)
        self.config_data = load_config()
        width, height = 1470, 930
        sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
        width, height = min(width, sw - 80), min(height, sh - 120)
        self.geometry(f"{width}x{height}+{(sw - width) // 2}+{max(0, (sh - height) // 3)}")
        self.minsize(900, 600)
        self.tk.call("tk", "scaling", self.winfo_fpixels("1i") / 72 * 1.25)
        self.pages = {}
        self.nav = {}
        self.current = None
        self.build()
        self.show("Chat")
        self.protocol("WM_DELETE_WINDOW", self.close)
        self.after(4000, self.update_tick)

    def update_tick(self):
        threading.Thread(target=self.update_worker, daemon=True).start()
        self.after(UPDATE_CHECK_SECONDS * 1000, self.update_tick)

    def update_worker(self):
        try:
            info = check_for_update(self.config_data)
        except Exception:
            return
        if info and (self.pending_update is None or self.pending_update["version"] != info["version"]):
            self.after(0, lambda: self.update_found(info))

    def update_found(self, info):
        self.pending_update = info
        self.update_btn.pack(side="right", padx=8)
        self.show_update_popup()

    def show_update_popup(self):
        info = self.pending_update
        if not info or (self.popup is not None and self.popup.winfo_exists()):
            return
        pop = tk.Toplevel(self)
        self.popup = pop
        pop.title("StribHub update")
        apply_icon(pop)
        pop.configure(bg=PANEL)
        pop.resizable(False, False)
        pop.attributes("-topmost", True)
        tk.Label(pop, text="A new version of StribHub is ready", bg=PANEL, fg=FG, font=("Segoe UI", 13, "bold")).pack(
            padx=30, pady=(24, 4))
        tk.Label(pop, text=f"You have v{VERSION}. The new version is v{info['version']}.", bg=PANEL, fg=MUTED,
                 font=("Segoe UI", 10)).pack(padx=30)
        if info.get("notes"):
            tk.Label(pop, text=info["notes"], bg=PANEL, fg=FG, font=("Segoe UI", 10), wraplength=420,
                     justify="left").pack(padx=30, pady=(10, 0))
        tk.Label(pop, text="StribHub will restart. StribMeme closes with it, so reopen it from its tab afterwards.",
                 bg=PANEL, fg=MUTED, font=("Segoe UI", 9), wraplength=420, justify="left").pack(padx=30, pady=(10, 0))
        self.popup_status = tk.Label(pop, text="", bg=PANEL, fg=ACCENT, font=("Segoe UI", 10), wraplength=420)
        self.popup_status.pack(pady=(8, 0))
        row = tk.Frame(pop, bg=PANEL)
        row.pack(pady=(10, 24))
        self.popup_go = tk.Button(row, text="Update now", width=14, bg=ACCENT, fg=ACCENT_INK, relief="flat",
                                  activebackground=ACCENT, font=("Segoe UI", 11, "bold"), cursor="hand2",
                                  command=self.start_update)
        self.popup_go.pack(side="left", padx=6)
        self.popup_later = tk.Button(row, text="Later", width=10, bg=PANEL, fg=FG, relief="flat",
                                     activebackground=LINE, font=("Segoe UI", 10), cursor="hand2",
                                     command=pop.destroy)
        self.popup_later.pack(side="left", padx=6)
        pop.update_idletasks()
        x = self.winfo_rootx() + (self.winfo_width() - pop.winfo_reqwidth()) // 2
        y = self.winfo_rooty() + 120
        pop.geometry(f"+{max(0, x)}+{max(0, y)}")

    def start_update(self):
        self.popup_go.config(state="disabled", text="Updating…")
        self.popup_later.config(state="disabled")
        self.popup_status.config(text="Downloading…", fg=ACCENT)
        threading.Thread(target=self.update_job, daemon=True).start()

    def update_job(self):
        info = self.pending_update
        try:
            with tempfile.TemporaryDirectory() as tmp:
                path = download_update(info, tmp)
                self.after(0, lambda: self.popup_status.config(text="Installing…"))
                apply_update_zip(path, HERE)
        except Exception as exc:
            message = str(exc)[:200]
            self.after(0, lambda: self.popup_status.config(text=f"Update failed: {message}", fg=DANGER))
            self.after(0, lambda: self.popup_go.config(state="normal", text="Try again"))
            self.after(0, lambda: self.popup_later.config(state="normal"))
            return
        self.after(0, self.finish_update)

    def finish_update(self):
        self.relaunch = True
        self.close()

    def hub_accept(self, hwnd):
        cmd = cmdline_of(hwnd)
        if cmd is None:
            return True
        if self.user.get("legacy"):
            return "--hub-user=" not in cmd
        return f"--hub-user={self.user['name']}" in cmd

    def launch_stribmeme(self):
        exe = self.config_data.get("stribmeme_exe") or ""
        if not exe or not Path(exe).exists():
            raise OSError("StribMeme program not set. An admin can set it on the Admin page")
        if self.user.get("legacy"):
            subprocess.Popen([exe])
            return
        env = dict(os.environ)
        env["PUMPCOPYBOT_DATA_DIR"] = str(self.paths["stribmeme"])
        subprocess.Popen([exe, f"--hub-user={self.user['name']}"], env=env)

    def launch_taskforge(self):
        exe = self.config_data.get("taskforge_exe") or ""
        if not exe or not Path(exe).exists():
            raise OSError("TaskForge program not set. An admin can set it on the Admin page")
        if self.user.get("legacy"):
            subprocess.Popen([exe])
            return
        subprocess.Popen([exe, f"--user-data-dir={self.paths['taskforge']}", f"--hub-user={self.user['name']}"])

    def build(self):
        bar = tk.Frame(self, bg=PANEL, highlightbackground=LINE, highlightthickness=1)
        bar.pack(fill="x")
        self.logo = wide_logo(40)
        tk.Label(bar, image=self.logo, bg=PANEL).pack(side="left", padx=(16, 26), pady=9)

        if self.paths["stribcro"] is not None:
            os.environ["STRIBCRO_DATA_DIR"] = str(self.paths["stribcro"])
        else:
            os.environ.pop("STRIBCRO_DATA_DIR", None)
        local_cro = HERE / "stribcro.py"
        stribcro = load_module("stribcro_app", str(local_cro))
        sm = DockPage(self, "StribMeme", self.launch_stribmeme, "stribmeme", None, self.hub_accept, True)
        self.pages["Chat"] = AssistantChat(self, self.config_data, self.paths["chat"])
        self.pages["TaskForge"] = DockPage(self, "TaskForge", self.launch_taskforge, "taskforge", None,
                                           self.hub_accept, True)
        self.pages["StribBet"] = BetPage(self, self.config_data["betting"], self.paths["browser"])
        self.pages["StribMeme"] = sm
        self.pages["StribCro"] = PanelPage(
            self, "StribCro", "Save up to 5 images, then tell the AI what to do with your mouse, keyboard and images",
            stribcro.App)
        if self.user["role"] == "admin":
            self.pages["Admin"] = AdminPage(self, self)

        for name in self.pages:
            label = tk.Label(bar, text=name, bg=PANEL, fg=MUTED, font=("Segoe UI", 11, "bold"), padx=16, pady=10,
                             cursor="hand2")
            label.pack(side="left")
            label.bind("<Button-1>", lambda e, n=name: self.show(n))
            self.nav[name] = label

        tk.Button(bar, text="Sign out", bg=PANEL, fg=FG, relief="flat", activebackground=LINE, activeforeground=FG,
                  font=("Segoe UI", 10), cursor="hand2", command=self.sign_out).pack(side="right", padx=(4, 12))
        self.update_btn = tk.Button(bar, text="Update available", bg=ACCENT, fg=ACCENT_INK, relief="flat",
                                    activebackground=ACCENT, font=("Segoe UI", 10, "bold"), cursor="hand2",
                                    command=self.show_update_popup)
        tk.Label(bar, text=f"v{VERSION}", bg=PANEL, fg=MUTED, font=("Segoe UI", 9)).pack(side="right", padx=6)
        tk.Label(bar, text=f"{self.user['name']}" + ("  (admin)" if self.user["role"] == "admin" else ""), bg=PANEL,
                 fg=MUTED, font=("Segoe UI", 10)).pack(side="right", padx=8)

    def show(self, name):
        if self.current:
            previous = self.pages[self.current]
            previous.pack_forget()
            hide = getattr(previous, "on_hide", None)
            if hide:
                hide()
        self.current = name
        page = self.pages[name]
        page.pack(fill="both", expand=True)
        for n, label in self.nav.items():
            label.config(fg=ACCENT if n == name else MUTED, bg="#16202b" if n == name else PANEL)
        self.after(50, page.on_show)

    def sign_out(self):
        self.restart = True
        self.close()

    def close(self):
        for page in self.pages.values():
            try:
                page.undock()
            except Exception:
                pass
        panel = self.pages.get("StribCro")
        if panel is not None:
            try:
                panel.panel.shutdown()
            except Exception:
                pass
        self.destroy()


def main():
    try:
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("Stribbot.StribHub")
    except Exception:
        pass
    while True:
        users = load_users()
        login = LoginWindow(users)
        login.mainloop()
        if login.result is None:
            return
        hub = Hub(login.result, users)
        hub.mainloop()
        if hub.relaunch:
            subprocess.Popen([sys.executable, str(Path(__file__).resolve())], cwd=str(HERE))
            return
        if not hub.restart:
            return


if __name__ == "__main__":
    main()
