import base64
import ctypes
import io
import json
import math
import os
import re
import threading
import time
import tkinter as tk
import urllib.error
import urllib.request
from ctypes import wintypes
from pathlib import Path
from tkinter import filedialog, simpledialog

import cv2
import numpy as np
from PIL import Image, ImageGrab, ImageTk

ctypes.windll.shcore.SetProcessDpiAwareness(2)
user32 = ctypes.windll.user32

HERE = Path(__file__).parent
USER_DATA = os.environ.get("STRIBCRO_DATA_DIR")
DATA_DIR = Path(USER_DATA) if USER_DATA else HERE
DATA_DIR.mkdir(parents=True, exist_ok=True)
SETTINGS = DATA_DIR / "settings.json"
SLOTS_DIR = DATA_DIR / "slots"
SLOT_COUNT = 5
THUMB = 40
DEFAULT_MATCH = 0.85
API_URL = "https://api.anthropic.com/v1/messages"
DEFAULT_MODEL = "claude-haiku-5-5"
VISION_MODEL = "claude-sonnet-5-5"
HOTKEY_STOP = 0x78
MAX_TOTAL_SECONDS = 1800
MAX_REPEAT = 100000
TICK = 0.008

BG = "#16191f"
FG = "#e6e8eb"
MUTED = "#8a909a"
ACCENT = "#38ddc3"
STOP = "#ff6b6b"
FIELD = "#232831"

SYSTEM_PROMPT = """You turn a plain-English description of mouse and keyboard actions into a macro for Windows.
Reply with ONLY a JSON array of steps. No prose, no code fences.

Step types (all numbers are plain numbers, times in seconds, distances in screen pixels):
{"type":"mouse_down","button":"left|right|middle"}
{"type":"mouse_up","button":"left|right|middle"}
{"type":"click","button":"left|right|middle","count":1}
{"type":"click_on","target":"the green Sell button","button":"left","count":1}   the app looks at the screen, finds the described thing and clicks it
{"type":"click_image","image":1,"button":"left","count":1}   click saved image #1 (images are numbered 1 to 5 and saved by the user); waits up to 5 seconds for it to appear
{"type":"wait_image","image":1,"timeout":30}   wait until saved image #1 is visible on screen
{"type":"move_rel","dx":0,"dy":0,"duration":0.5}   relative move from where the cursor is now; +dx is right, +dy is down
{"type":"move_abs","x":0,"y":0,"duration":0.5}      only when the user gives exact coordinates
{"type":"scroll","amount":3}                         positive scrolls up, negative scrolls down
{"type":"key","key":"ctrl+c"}                        press and release a key or combo
{"type":"key_down","key":"w"}
{"type":"key_up","key":"w"}
{"type":"type","text":"hello"}
{"type":"wait","seconds":1}
{"type":"repeat","times":5,"steps":[...]}            times may be a number or "forever"

Rules:
- Whenever the user says to click, press or select something by NAME or description (a button, icon, menu item), use click_on with a short clear description. Use plain click only when they mean "click where the mouse already is".
- "image #N" or "picture N" always means the user's saved image number N, so use click_image or wait_image with that number. Only use slots listed as saved in the message.
- Rotating, turning or looking right means move_rel with positive dx; left is negative dx; up is negative dy; down is positive dy.
- "Slowly" means long durations. "Very slowly" means several seconds for a few hundred pixels. If no distance is given, use a sensible default (for example 300 pixels).
- When the user says to hold a mouse button, use mouse_down, then the other steps, then mouse_up. Always end by releasing anything you pressed.
- Convert minutes to seconds. Use repeat for anything repeated.
- Do only what the user asked. Do not invent extra actions.
- If the request is unclear, impossible, or not about mouse and keyboard actions, reply with [{"type":"error","message":"short reason"}].
"""

PUL = ctypes.POINTER(ctypes.c_ulong)


class MOUSEINPUT(ctypes.Structure):
    _fields_ = [("dx", wintypes.LONG), ("dy", wintypes.LONG), ("mouseData", wintypes.DWORD),
                ("dwFlags", wintypes.DWORD), ("time", wintypes.DWORD), ("dwExtraInfo", ctypes.c_size_t)]


class KEYBDINPUT(ctypes.Structure):
    _fields_ = [("wVk", wintypes.WORD), ("wScan", wintypes.WORD), ("dwFlags", wintypes.DWORD),
                ("time", wintypes.DWORD), ("dwExtraInfo", ctypes.c_size_t)]


class HARDWAREINPUT(ctypes.Structure):
    _fields_ = [("uMsg", wintypes.DWORD), ("wParamL", wintypes.WORD), ("wParamH", wintypes.WORD)]


class INPUT_UNION(ctypes.Union):
    _fields_ = [("mi", MOUSEINPUT), ("ki", KEYBDINPUT), ("hi", HARDWAREINPUT)]


class INPUT(ctypes.Structure):
    _fields_ = [("type", wintypes.DWORD), ("u", INPUT_UNION)]


MOUSE_FLAGS = {
    "left": (0x0002, 0x0004),
    "right": (0x0008, 0x0010),
    "middle": (0x0020, 0x0040),
}

SPECIAL_KEYS = {
    "ctrl": 0x11, "control": 0x11, "shift": 0x10, "alt": 0x12, "win": 0x5B, "windows": 0x5B,
    "enter": 0x0D, "return": 0x0D, "tab": 0x09, "esc": 0x1B, "escape": 0x1B, "space": 0x20,
    "backspace": 0x08, "delete": 0x2E, "del": 0x2E, "insert": 0x2D,
    "up": 0x26, "down": 0x28, "left": 0x25, "right": 0x27,
    "home": 0x24, "end": 0x23, "pageup": 0x21, "pagedown": 0x22,
    "capslock": 0x14,
}
for _i in range(1, 13):
    SPECIAL_KEYS[f"f{_i}"] = 0x6F + _i
EXTENDED_VKS = {0x26, 0x28, 0x25, 0x27, 0x24, 0x23, 0x21, 0x22, 0x2D, 0x2E, 0x5B}

STEP_TYPES = {"mouse_down", "mouse_up", "click", "click_on", "click_image", "wait_image", "move_rel", "move_abs", "scroll", "key", "key_down",
              "key_up", "type", "wait", "repeat"}


def send_inputs(items):
    n = len(items)
    arr = (INPUT * n)(*items)
    user32.SendInput(n, arr, ctypes.sizeof(INPUT))


def mouse_input(dx=0, dy=0, flags=0, data=0):
    inp = INPUT()
    inp.type = 0
    inp.u.mi = MOUSEINPUT(dx, dy, data & 0xFFFFFFFF, flags, 0, 0)
    return inp


def key_input(vk=0, scan=0, flags=0):
    inp = INPUT()
    inp.type = 1
    inp.u.ki = KEYBDINPUT(vk, scan, flags, 0, 0)
    return inp


def vk_for(name):
    name = str(name).strip().lower()
    if name in SPECIAL_KEYS:
        return SPECIAL_KEYS[name]
    if len(name) == 1:
        res = user32.VkKeyScanW(ord(name))
        if res != -1:
            return res & 0xFF
    raise ValueError(f"unknown key '{name}'")


def num(value, lo, hi, default=0.0):
    try:
        v = float(value)
    except (TypeError, ValueError):
        v = default
    if math.isnan(v):
        v = default
    return max(lo, min(hi, v))


def validate(steps, depth=0):
    if not isinstance(steps, list):
        raise ValueError("the plan wasn't a list of steps")
    if depth > 4:
        raise ValueError("steps are nested too deeply")
    out = []
    for raw in steps:
        if not isinstance(raw, dict):
            raise ValueError("a step wasn't an object")
        kind = raw.get("type")
        if kind == "error":
            raise ValueError(str(raw.get("message", "the request couldn't be turned into steps"))[:200])
        if kind not in STEP_TYPES:
            raise ValueError(f"unknown step type '{kind}'")
        step = {"type": kind}
        if kind in ("mouse_down", "mouse_up", "click"):
            button = str(raw.get("button", "left")).lower()
            if button not in MOUSE_FLAGS:
                raise ValueError(f"unknown mouse button '{button}'")
            step["button"] = button
            if kind == "click":
                step["count"] = int(num(raw.get("count", 1), 1, 50, 1))
        elif kind == "click_on":
            target = str(raw.get("target", "")).strip()[:200]
            if not target:
                raise ValueError("click_on needs a description of what to click")
            button = str(raw.get("button", "left")).lower()
            if button not in MOUSE_FLAGS:
                raise ValueError(f"unknown mouse button '{button}'")
            step["target"] = target
            step["button"] = button
            step["count"] = int(num(raw.get("count", 1), 1, 50, 1))
        elif kind in ("click_image", "wait_image"):
            try:
                slot = int(raw.get("image"))
            except (TypeError, ValueError):
                slot = 0
            if slot < 1 or slot > SLOT_COUNT:
                raise ValueError(f"image numbers go from 1 to {SLOT_COUNT}")
            step["image"] = slot
            if kind == "click_image":
                button = str(raw.get("button", "left")).lower()
                if button not in MOUSE_FLAGS:
                    raise ValueError(f"unknown mouse button '{button}'")
                step["button"] = button
                step["count"] = int(num(raw.get("count", 1), 1, 50, 1))
                step["wait"] = num(raw.get("wait"), 0, 300, 5)
            else:
                step["timeout"] = num(raw.get("timeout"), 0, 3600, 30)
        elif kind == "move_rel":
            step["dx"] = num(raw.get("dx"), -20000, 20000)
            step["dy"] = num(raw.get("dy"), -20000, 20000)
            step["duration"] = num(raw.get("duration"), 0, 600, 0.3)
        elif kind == "move_abs":
            step["x"] = num(raw.get("x"), -20000, 20000)
            step["y"] = num(raw.get("y"), -20000, 20000)
            step["duration"] = num(raw.get("duration"), 0, 600, 0.3)
        elif kind == "scroll":
            step["amount"] = int(num(raw.get("amount"), -100, 100, 1))
        elif kind in ("key", "key_down", "key_up"):
            key = str(raw.get("key", "")).strip()
            for part in key.split("+"):
                vk_for(part)
            step["key"] = key
            step["hold"] = num(raw.get("hold"), 0, 10, 0.08)
        elif kind == "type":
            step["text"] = str(raw.get("text", ""))[:2000]
        elif kind == "wait":
            step["seconds"] = num(raw.get("seconds"), 0, 3600, 1)
        elif kind == "repeat":
            times = raw.get("times", 1)
            if isinstance(times, str) and times.lower() in ("forever", "infinite", "inf"):
                step["times"] = "forever"
            else:
                step["times"] = int(num(times, 1, MAX_REPEAT, 1))
            step["steps"] = validate(raw.get("steps", []), depth + 1)
        out.append(step)
    return out


def estimate(steps):
    total = 0.0
    for s in steps:
        k = s["type"]
        if k in ("move_rel", "move_abs"):
            total += s["duration"]
        elif k == "wait":
            total += s["seconds"]
        elif k == "click":
            total += 0.1 * s["count"]
        elif k == "click_on":
            total += 3.0 + 0.1 * s["count"]
        elif k == "click_image":
            total += 0.5 + 0.1 * s["count"]
        elif k == "wait_image":
            total += s["timeout"]
        elif k == "type":
            total += 0.01 * len(s["text"])
        elif k == "repeat":
            inner = estimate(s["steps"])
            if inner is None or s["times"] == "forever":
                return None
            total += inner * s["times"]
        else:
            total += 0.02
    return total


def describe(step, indent=""):
    k = step["type"]
    if k == "mouse_down":
        line = f"hold {step['button']} button"
    elif k == "mouse_up":
        line = f"release {step['button']} button"
    elif k == "click":
        line = f"{step['button']} click x{step['count']}"
    elif k == "click_image":
        line = f"{step['button']} click image #{step['image']} x{step['count']}"
    elif k == "wait_image":
        line = f"wait for image #{step['image']}"
    elif k == "click_on":
        line = f"find and click '{step['target'][:40]}' x{step['count']}"
    elif k == "move_rel":
        line = f"move {step['dx']:.0f},{step['dy']:.0f} px over {step['duration']:.1f}s"
    elif k == "move_abs":
        line = f"move to {step['x']:.0f},{step['y']:.0f}"
    elif k == "scroll":
        line = f"scroll {step['amount']}"
    elif k == "key":
        line = f"press {step['key']}"
    elif k == "key_down":
        line = f"hold key {step['key']}"
    elif k == "key_up":
        line = f"release key {step['key']}"
    elif k == "type":
        line = f"type '{step['text'][:30]}'"
    elif k == "wait":
        line = f"wait {step['seconds']:.1f}s"
    else:
        line = f"repeat {step['times']}x:"
    lines = [indent + line]
    if k == "repeat":
        for inner in step["steps"]:
            lines.extend(describe(inner, indent + "  "))
    return lines


class Executor:
    def __init__(self, finder=None, images=None):
        self.stop = threading.Event()
        self.held_buttons = set()
        self.held_keys = set()
        self.finder = finder
        self.images = images

    def sleep(self, seconds):
        end = time.perf_counter() + seconds
        while not self.stop.is_set():
            left = end - time.perf_counter()
            if left <= 0:
                return
            time.sleep(min(left, 0.01))

    def key_event(self, vk, up):
        flags = 0x0008 | (0x0002 if up else 0)
        if vk in EXTENDED_VKS:
            flags |= 0x0001
        scan = user32.MapVirtualKeyW(vk, 0)
        send_inputs([key_input(vk=vk, scan=scan, flags=flags)])

    def click_at_cursor(self, button, count):
        down, up = MOUSE_FLAGS[button]
        for _ in range(count):
            if self.stop.is_set():
                return
            send_inputs([mouse_input(flags=down)])
            self.sleep(0.06)
            send_inputs([mouse_input(flags=up)])
            self.sleep(0.08)

    def click_on(self, target, button, count):
        if self.finder is None:
            raise RuntimeError("no way to look at the screen")
        found = self.finder(target)
        if self.stop.is_set():
            return
        if found is None:
            raise RuntimeError(f"couldn't find '{target[:40]}' on screen")
        self.press_at(found[0], found[1], button, count)

    def press_at(self, x, y, button, count):
        self.move_abs(x, y, 0.25)
        send_inputs([mouse_input(1, 1, 0x0001)])
        self.sleep(0.05)
        send_inputs([mouse_input(-1, -1, 0x0001)])
        self.sleep(0.15)
        self.click_at_cursor(button, count)

    def wait_for_image(self, slot, wait):
        if self.images is None:
            raise RuntimeError("no saved images available")
        deadline = time.perf_counter() + wait
        while not self.stop.is_set():
            found = self.images(slot)
            if found is not None:
                return found
            if time.perf_counter() >= deadline:
                return None
            self.sleep(0.25)
        return None

    def click_image(self, slot, button, count, wait):
        found = self.wait_for_image(slot, wait)
        if self.stop.is_set():
            return
        if found is None:
            raise RuntimeError(f"couldn't find image #{slot} on screen")
        self.press_at(found[0], found[1], button, count)

    def release_all(self):
        for button in list(self.held_buttons):
            send_inputs([mouse_input(flags=MOUSE_FLAGS[button][1])])
        self.held_buttons.clear()
        for vk in list(self.held_keys):
            self.key_event(vk, True)
        self.held_keys.clear()

    def move_rel(self, dx, dy, duration):
        if duration <= 0.02:
            send_inputs([mouse_input(int(round(dx)), int(round(dy)), 0x0001)])
            return
        start = time.perf_counter()
        sent_x = sent_y = 0
        while not self.stop.is_set():
            t = min(1.0, (time.perf_counter() - start) / duration)
            tx, ty = int(round(dx * t)), int(round(dy * t))
            if tx != sent_x or ty != sent_y:
                send_inputs([mouse_input(tx - sent_x, ty - sent_y, 0x0001)])
                sent_x, sent_y = tx, ty
            if t >= 1.0:
                return
            time.sleep(TICK)

    def move_abs(self, x, y, duration):
        pt = wintypes.POINT()
        user32.GetCursorPos(ctypes.byref(pt))
        sx, sy = pt.x, pt.y
        if duration <= 0.02:
            user32.SetCursorPos(int(x), int(y))
            return
        start = time.perf_counter()
        while not self.stop.is_set():
            t = min(1.0, (time.perf_counter() - start) / duration)
            user32.SetCursorPos(int(sx + (x - sx) * t), int(sy + (y - sy) * t))
            if t >= 1.0:
                return
            time.sleep(TICK)

    def type_text(self, text):
        for ch in text:
            if self.stop.is_set():
                return
            if ch in "\r\n":
                vk = SPECIAL_KEYS["enter"]
                self.key_event(vk, False)
                self.key_event(vk, True)
            else:
                code = ord(ch)
                if code > 0xFFFF:
                    continue
                send_inputs([key_input(scan=code, flags=0x0004), key_input(scan=code, flags=0x0004 | 0x0002)])
            self.sleep(0.01)

    def run(self, steps):
        for step in steps:
            if self.stop.is_set():
                return
            k = step["type"]
            if k == "mouse_down":
                send_inputs([mouse_input(flags=MOUSE_FLAGS[step["button"]][0])])
                self.held_buttons.add(step["button"])
            elif k == "mouse_up":
                send_inputs([mouse_input(flags=MOUSE_FLAGS[step["button"]][1])])
                self.held_buttons.discard(step["button"])
            elif k == "click":
                self.click_at_cursor(step["button"], step["count"])
            elif k == "click_on":
                self.click_on(step["target"], step["button"], step["count"])
            elif k == "click_image":
                self.click_image(step["image"], step["button"], step["count"], step["wait"])
            elif k == "wait_image":
                if self.wait_for_image(step["image"], step["timeout"]) is None and not self.stop.is_set():
                    raise RuntimeError(f"image #{step['image']} never appeared")
            elif k == "move_rel":
                self.move_rel(step["dx"], step["dy"], step["duration"])
            elif k == "move_abs":
                self.move_abs(step["x"], step["y"], step["duration"])
            elif k == "scroll":
                send_inputs([mouse_input(flags=0x0800, data=step["amount"] * 120)])
            elif k == "key":
                vks = [vk_for(p) for p in step["key"].split("+")]
                for vk in vks:
                    self.key_event(vk, False)
                self.sleep(step.get("hold", 0.08))
                for vk in reversed(vks):
                    self.key_event(vk, True)
            elif k == "key_down":
                vk = vk_for(step["key"])
                self.key_event(vk, False)
                self.held_keys.add(vk)
            elif k == "key_up":
                vk = vk_for(step["key"])
                self.key_event(vk, True)
                self.held_keys.discard(vk)
            elif k == "type":
                self.type_text(step["text"])
            elif k == "wait":
                self.sleep(step["seconds"])
            elif k == "repeat":
                n = 0
                while not self.stop.is_set() and (step["times"] == "forever" or n < step["times"]):
                    self.run(step["steps"])
                    n += 1
                    self.sleep(0.005)


def ask_model(text, key, model, filled=()):
    body = json.dumps({
        "model": model,
        "max_tokens": 2000,
        "system": SYSTEM_PROMPT + "\nSaved images available: " + (", ".join(f"#{n}" for n in filled) or "none") + ".",
        "messages": [{"role": "user", "content": text}],
    }).encode()
    req = urllib.request.Request(API_URL, data=body, headers={
        "x-api-key": key,
        "anthropic-version": "2023-06-01",
        "content-type": "application/json",
    })
    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            data = json.loads(resp.read())
    except urllib.error.HTTPError as exc:
        detail = ""
        try:
            detail = json.loads(exc.read()).get("error", {}).get("message", "")
        except Exception:
            pass
        raise RuntimeError(f"AI error {exc.code}: {detail or exc.reason}")
    except urllib.error.URLError as exc:
        raise RuntimeError(f"couldn't reach the AI ({exc.reason})")
    parts = [b.get("text", "") for b in data.get("content", []) if b.get("type") == "text"]
    return "".join(parts)


def find_target(target, key, model):
    shot = ImageGrab.grab().convert("RGB")
    width, height = shot.size
    scale = min(1.0, 1568 / max(width, height))
    sent = shot.resize((int(width * scale), int(height * scale))) if scale < 1.0 else shot
    buf = io.BytesIO()
    sent.save(buf, format="JPEG", quality=85)
    prompt = (
        f"This is a screenshot, {sent.size[0]}x{sent.size[1]} pixels. Find this on screen: {target}\n"
        'Reply with ONLY JSON: {"found":true,"x":<int>,"y":<int>} giving the pixel at the center of it in this image, '
        'or {"found":false} if it is not visible.'
    )
    body = json.dumps({
        "model": model,
        "max_tokens": 100,
        "messages": [{"role": "user", "content": [
            {"type": "image", "source": {"type": "base64", "media_type": "image/jpeg",
                                         "data": base64.b64encode(buf.getvalue()).decode()}},
            {"type": "text", "text": prompt},
        ]}],
    }).encode()
    req = urllib.request.Request(API_URL, data=body, headers={
        "x-api-key": key,
        "anthropic-version": "2023-06-01",
        "content-type": "application/json",
    })
    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            data = json.loads(resp.read())
    except urllib.error.HTTPError as exc:
        raise RuntimeError(f"AI error {exc.code} while looking at the screen")
    except urllib.error.URLError as exc:
        raise RuntimeError(f"couldn't reach the AI ({exc.reason})")
    text = "".join(b.get("text", "") for b in data.get("content", []) if b.get("type") == "text")
    match = re.search(r"\{.*\}", text, re.S)
    if not match:
        return None
    try:
        result = json.loads(match.group(0))
    except ValueError:
        return None
    if not result.get("found"):
        return None
    return int(float(result["x"]) / scale), int(float(result["y"]) / scale)


def virtual_origin():
    return user32.GetSystemMetrics(76), user32.GetSystemMetrics(77)


def grab_screen():
    return ImageGrab.grab(all_screens=True)


def to_gray(img):
    return cv2.cvtColor(np.array(img.convert("RGB")), cv2.COLOR_RGB2GRAY)


def locate_template(tpl, match):
    screen = to_gray(grab_screen())
    if tpl.shape[0] > screen.shape[0] or tpl.shape[1] > screen.shape[1]:
        return None
    res = cv2.matchTemplate(screen, tpl, cv2.TM_CCOEFF_NORMED)
    _, score, _, loc = cv2.minMaxLoc(res)
    if score < match:
        return None
    ox, oy = virtual_origin()
    return ox + loc[0] + tpl.shape[1] // 2, oy + loc[1] + tpl.shape[0] // 2


class Snipper(tk.Toplevel):
    def __init__(self, master, on_done):
        super().__init__(master)
        self.on_done = on_done
        self.shot = grab_screen()
        ox, oy = virtual_origin()
        w, h = self.shot.size
        self.overrideredirect(True)
        self.attributes("-topmost", True)
        self.geometry(f"{w}x{h}+{ox}+{oy}")
        self.canvas = tk.Canvas(self, width=w, height=h, highlightthickness=0, cursor="crosshair")
        self.canvas.pack()
        dim = Image.blend(self.shot.convert("RGB"), Image.new("RGB", self.shot.size, "black"), 0.35)
        self.photo = ImageTk.PhotoImage(dim)
        self.canvas.create_image(0, 0, image=self.photo, anchor="nw")
        self.canvas.create_text(w // 2, 30, text="Drag around the thing to save   -   Esc to cancel",
                                fill="white", font=("Segoe UI", 14, "bold"))
        self.start = None
        self.rect = None
        self.canvas.bind("<ButtonPress-1>", self.press)
        self.canvas.bind("<B1-Motion>", self.drag)
        self.canvas.bind("<ButtonRelease-1>", self.release)
        self.bind("<Escape>", lambda e: self.finish(None))
        self.focus_force()

    def press(self, e):
        self.start = (e.x, e.y)
        self.rect = self.canvas.create_rectangle(e.x, e.y, e.x, e.y, outline=ACCENT, width=2)

    def drag(self, e):
        if self.rect:
            self.canvas.coords(self.rect, *self.start, e.x, e.y)

    def release(self, e):
        if not self.start:
            return
        x0, y0 = self.start
        box = (min(x0, e.x), min(y0, e.y), max(x0, e.x), max(y0, e.y))
        if box[2] - box[0] < 4 or box[3] - box[1] < 4:
            self.finish(None)
            return
        self.finish(self.shot.crop(box))

    def finish(self, img):
        self.destroy()
        self.on_done(img)


def parse_plan(raw):
    raw = raw.strip()
    raw = re.sub(r"^```(?:json)?\s*|\s*```$", "", raw)
    start, end = raw.find("["), raw.rfind("]")
    if start == -1 or end == -1:
        raise ValueError("the AI didn't return steps")
    return validate(json.loads(raw[start:end + 1]))


class App(tk.Frame):
    def __init__(self, master=None):
        super().__init__(master, bg=BG)
        self.executor = None
        self.busy = False
        self.settings = {}
        self.templates = [None] * SLOT_COUNT
        self.thumbs = [None] * SLOT_COUNT
        self.slot_btns = []
        self.match_cached = DEFAULT_MATCH
        self.load()
        self.build()
        self.load_slots()
        self.poll_hotkey()

    def build(self):
        slots = tk.Frame(self, bg=BG)
        slots.pack(padx=6, pady=(8, 2), anchor="w")
        tk.Label(slots, text="Images", bg=BG, fg=MUTED, font=("Segoe UI", 8)).grid(row=0, column=0, padx=(0, 6))
        for i in range(SLOT_COUNT):
            b = tk.Label(slots, bg=FIELD, fg=MUTED, text=f"#{i + 1}", font=("Segoe UI", 8), width=6, height=3,
                         cursor="hand2")
            b.grid(row=0, column=i + 1, padx=2)
            b.bind("<Button-1>", lambda e, i=i: self.snip(i))
            b.bind("<Shift-Button-1>", lambda e, i=i: self.load_file(i))
            b.bind("<Button-3>", lambda e, i=i: self.clear(i))
            self.slot_btns.append(b)
        tk.Label(slots, text="click = grab, shift+click = file, right-click = clear", bg=BG, fg=MUTED,
                 font=("Segoe UI", 7)).grid(row=0, column=SLOT_COUNT + 1, padx=8)
        self.box = tk.Text(self, width=56, height=5, bg=FIELD, fg=FG, insertbackground=FG, relief="flat",
                           font=("Segoe UI", 9), wrap="word")
        self.box.pack(padx=6, pady=(6, 3), fill="x")
        self.box.insert("1.0", self.settings.get("last", ""))
        self.box.bind("<Control-Return>", lambda e: (self.run_clicked(), "break")[1])

        row = tk.Frame(self, bg=BG)
        row.pack(fill="x", padx=6)
        self.run_btn = tk.Button(row, text="Run", font=("Segoe UI", 9, "bold"), bg=ACCENT, fg="#062b27",
                                 activebackground=ACCENT, relief="flat", width=9, command=self.run_clicked,
                                 cursor="hand2")
        self.run_btn.pack(side="left")
        self.stop_btn = tk.Button(row, text="Stop (F9)", font=("Segoe UI", 9, "bold"), bg=STOP, fg="#2b0606",
                                  activebackground=STOP, relief="flat", width=9, command=self.stop_clicked,
                                  cursor="hand2")
        self.stop_btn.pack(side="left", padx=4)
        tk.Label(row, text="Delay", bg=BG, fg=MUTED, font=("Segoe UI", 8)).pack(side="left", padx=(6, 2))
        self.delay = tk.StringVar(value=str(self.settings.get("delay", "3")))
        tk.Entry(row, textvariable=self.delay, width=3, bg=FIELD, fg=FG, insertbackground=FG, relief="flat",
                 font=("Segoe UI", 9), justify="center").pack(side="left")
        tk.Label(row, text="Match", bg=BG, fg=MUTED, font=("Segoe UI", 8)).pack(side="left", padx=(8, 2))
        self.match = tk.StringVar(value=str(self.settings.get("match", DEFAULT_MATCH)))
        tk.Entry(row, textvariable=self.match, width=4, bg=FIELD, fg=FG, insertbackground=FG, relief="flat",
                 font=("Segoe UI", 9), justify="center").pack(side="left")
        key_btn = tk.Label(row, text="key", bg=BG, fg=MUTED, font=("Segoe UI", 8, "underline"), cursor="hand2")
        key_btn.pack(side="right")
        key_btn.bind("<Button-1>", lambda e: self.ask_key())

        self.plan = tk.Text(self, width=56, height=5, bg=BG, fg=MUTED, relief="flat", font=("Consolas", 8),
                            state="disabled", wrap="none")
        self.plan.pack(padx=6, pady=(3, 0), fill="x")
        self.status = tk.Label(self, text="Describe what to do, then Run (Ctrl+Enter)", bg=BG, fg=MUTED,
                               font=("Segoe UI", 8), anchor="w")
        self.status.pack(fill="x", padx=6, pady=(0, 5))

    def load(self):
        if SETTINGS.exists():
            try:
                self.settings = json.loads(SETTINGS.read_text())
            except ValueError:
                self.settings = {}

    def save(self):
        self.settings["last"] = self.box.get("1.0", "end").strip()
        self.settings["delay"] = self.delay.get().strip() or "3"
        self.settings["match"] = self.match.get().strip() or str(DEFAULT_MATCH)
        SETTINGS.write_text(json.dumps(self.settings))

    def set_slot(self, i, img, save=True):
        path = SLOTS_DIR / f"slot{i + 1}.png"
        if img is None:
            self.templates[i] = None
            self.thumbs[i] = None
            self.slot_btns[i].config(image="", text=f"#{i + 1}", width=6, height=3)
            if save and path.exists():
                path.unlink()
            return
        img = img.convert("RGB")
        if save:
            SLOTS_DIR.mkdir(exist_ok=True)
            img.save(path)
        self.templates[i] = to_gray(img)
        thumb = img.copy()
        thumb.thumbnail((THUMB * 2, THUMB))
        self.thumbs[i] = ImageTk.PhotoImage(thumb)
        self.slot_btns[i].config(image=self.thumbs[i], text="", width=thumb.size[0], height=thumb.size[1])

    def load_slots(self):
        SLOTS_DIR.mkdir(exist_ok=True)
        for i in range(SLOT_COUNT):
            path = SLOTS_DIR / f"slot{i + 1}.png"
            if path.exists():
                self.set_slot(i, Image.open(path), save=False)

    def snip(self, i):
        if self.busy:
            return
        top = self.winfo_toplevel()
        top.withdraw()
        self.after(200, lambda: Snipper(top, lambda img: self.snipped(i, img)))

    def snipped(self, i, img):
        self.winfo_toplevel().deiconify()
        if img is not None:
            self.set_slot(i, img)
            self.set_status(f"Image #{i + 1} saved")

    def load_file(self, i):
        if self.busy:
            return
        path = filedialog.askopenfilename(filetypes=[("Images", "*.png *.jpg *.jpeg *.bmp")])
        if path:
            self.set_slot(i, Image.open(path))
            self.set_status(f"Image #{i + 1} loaded")

    def clear(self, i):
        if not self.busy:
            self.set_slot(i, None)
            self.set_status(f"Image #{i + 1} cleared")

    def locate_slot(self, slot):
        tpl = self.templates[slot - 1]
        if tpl is None:
            raise RuntimeError(f"image #{slot} is empty, save one first")
        return locate_template(tpl, self.match_cached)

    def api_key(self):
        return (os.environ.get("ANTHROPIC_API_KEY") or self.settings.get("api_key") or "").strip()

    def ask_key(self):
        key = simpledialog.askstring("AI key", "Paste your Anthropic API key:", show="*", parent=self)
        if key and key.strip():
            self.settings["api_key"] = key.strip()
            self.save()
            self.set_status("Key saved")

    def set_status(self, text, color=MUTED):
        self.after(0, lambda: self.status.config(text=text, fg=color))

    def show_plan(self, steps):
        lines = []
        for s in steps:
            lines.extend(describe(s))
        text = "\n".join(lines)

        def apply():
            self.plan.config(state="normal")
            self.plan.delete("1.0", "end")
            self.plan.insert("1.0", text)
            self.plan.config(state="disabled")

        self.after(0, apply)

    def run_clicked(self):
        if self.busy:
            return
        text = self.box.get("1.0", "end").strip()
        if not text:
            return
        key = self.api_key()
        if not key:
            self.ask_key()
            key = self.api_key()
            if not key:
                return
        try:
            delay = max(0.0, min(30.0, float(self.delay.get() or 0)))
        except ValueError:
            delay = 3.0
        try:
            self.match_cached = max(0.5, min(0.99, float(self.match.get())))
        except ValueError:
            self.match_cached = DEFAULT_MATCH
        self.save()
        self.busy = True
        self.run_btn.config(state="disabled")
        threading.Thread(target=self.work, args=(text, key, delay), daemon=True).start()

    def stop_clicked(self):
        if self.executor:
            self.executor.stop.set()

    def work(self, text, key, delay):
        vision_model = self.settings.get("vision_model") or VISION_MODEL
        ex = Executor(lambda target: find_target(target, key, vision_model), self.locate_slot)
        self.executor = ex
        try:
            self.set_status("Thinking...", ACCENT)
            model = self.settings.get("model") or DEFAULT_MODEL
            filled = [n + 1 for n, t in enumerate(self.templates) if t is not None]
            steps = parse_plan(ask_model(text, key, model, filled))
            if not steps:
                raise ValueError("no steps came back")
            total = estimate(steps)
            if total is not None and total > MAX_TOTAL_SECONDS:
                raise ValueError(f"that would take {total / 60:.0f} minutes, over the {MAX_TOTAL_SECONDS // 60} minute limit")
            self.show_plan(steps)
            end = time.perf_counter() + delay
            while not ex.stop.is_set() and time.perf_counter() < end:
                self.set_status(f"Starting in {end - time.perf_counter():.0f}s, click your target window", ACCENT)
                time.sleep(0.1)
            if not ex.stop.is_set():
                label = "until stopped" if total is None else f"~{total:.0f}s"
                self.set_status(f"Running ({label}), F9 to stop", ACCENT)
                ex.run(steps)
            self.set_status("Stopped" if ex.stop.is_set() else "Done", MUTED)
        except Exception as exc:
            self.set_status(str(exc)[:90], STOP)
        finally:
            ex.release_all()
            self.executor = None
            self.busy = False
            self.after(0, lambda: self.run_btn.config(state="normal"))

    def poll_hotkey(self):
        if user32.GetAsyncKeyState(HOTKEY_STOP) & 1:
            self.stop_clicked()
        self.after(40, self.poll_hotkey)

    def shutdown(self):
        self.stop_clicked()
        self.save()


if __name__ == "__main__":
    root = tk.Tk()
    root.title("StribCro")
    root.configure(bg=BG)
    root.resizable(False, False)
    root.attributes("-topmost", True)
    panel = App(root)
    panel.pack()
    root.protocol("WM_DELETE_WINDOW", lambda: (panel.shutdown(), root.destroy()))
    root.mainloop()
