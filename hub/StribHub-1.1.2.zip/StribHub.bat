@echo off
start "" pythonw "%~dp0stribhub.py"
