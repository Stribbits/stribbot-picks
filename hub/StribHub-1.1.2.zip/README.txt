StribHub
========
One app with StribBet, StribMeme and StribCro.

First time on a PC
1. Install Python 3.10 or newer from python.org (tick "Add python.exe to PATH").
2. Double-click Install.bat (one time only).
3. Double-click StribHub.bat.
4. The first screen asks you to create the admin account for this PC.
   Pick a username and password you will remember. Nobody else sees them.

Using it
- Chat: Claude inside the app. The first time, paste the chat key the studio admin gave you. It runs on the studio's Claude, so you don't need your own API key.
- TaskForge: open the Admin tab and set "TaskForge program on this PC" to your TaskForge .exe, then click the TaskForge tab and sign in.
- StribBet: the Stribbot picks website. Sign in with Google on the page to keep your own bets and see the standings.
- StribMeme: open the Admin tab and set "StribMeme program on this PC" to your StribMeme .exe, then click the StribMeme tab.
- StribCro: save up to 5 images, add your Anthropic API key (the small "key" link), then tell it what to do.
- Admin tab (admins only): create accounts for other people on this PC. Everyone has their own StribMeme, StribCro and StribBet data.

Needs a Chromium browser (Brave, Chrome or Edge) installed for the StribBet page.
