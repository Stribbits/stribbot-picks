@echo off
echo Installing what StribHub needs...
python -m pip install --upgrade pillow numpy opencv-python psutil
echo.
echo Done. Now double-click StribHub.bat
pause
